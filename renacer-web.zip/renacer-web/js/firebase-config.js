// ============================================================
//  CONFIGURACIÓN DE FIREBASE — Renacer Estéreo
//  Reemplaza estos valores por los de tu proyecto:
//  Consola de Firebase > Configuración del proyecto > Tus apps > Web
//  Mientras diga "PEGA_AQUI", la página muestra contenido de ejemplo.
// ============================================================
export const firebaseConfig = {
  apiKey: "PEGA_AQUI_TU_API_KEY",
  authDomain: "PEGA_AQUI.firebaseapp.com",
  projectId: "PEGA_AQUI",
  storageBucket: "PEGA_AQUI.appspot.com",
  messagingSenderId: "PEGA_AQUI",
  appId: "PEGA_AQUI"
};
